package com.spring_boot_rest_with.composite_pk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestWithCompositePkApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestWithCompositePkApplication.class, args);
	}

}
