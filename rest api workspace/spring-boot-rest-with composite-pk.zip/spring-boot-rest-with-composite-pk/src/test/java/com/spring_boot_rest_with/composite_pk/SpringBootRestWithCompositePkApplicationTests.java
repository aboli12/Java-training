package com.spring_boot_rest_with.composite_pk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestWithCompositePkApplicationTests {

	@Test
	void contextLoads() {
	}

}
