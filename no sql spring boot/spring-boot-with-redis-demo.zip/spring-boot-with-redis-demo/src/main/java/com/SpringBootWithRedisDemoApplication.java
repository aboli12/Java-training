package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWithRedisDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWithRedisDemoApplication.class, args);
	}

}
